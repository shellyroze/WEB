module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "J6fmmxyv!",
    DB: "mysql"
    };